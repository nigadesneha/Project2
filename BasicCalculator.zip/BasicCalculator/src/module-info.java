/**
 * 
 */
/**
 * @author kiran
 *
 */
module BasicCalculator {
	requires java.desktop;
}